const { io } = require("socket.io-client");
const Data = require("../models/data");

exports.getData = async (req, res) => {
  try {
    const data = await Data.find().sort({ _id: -1 }).limit(50);
    res.json(data);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// exports.postData = async (req, res) => {
//   const { value } = req.body;

//   if (!value || isNaN(value)) {
//     return res.status(400).json({ message: "Invalid data value" });
//   }

//   try {
//     const newData = new Data({ value });
//     await newData.save();

//     io.emit("dataUpdate", value);

//     res.status(201).json({ message: "Data saved successfully" });
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// };
