const express = require("express");
const router = express.Router();
const Data = require("../models/data");
const { getData } = require("../controller/data");

router.get("/data", getData);

//router.post("/data", postData);

module.exports = router;
