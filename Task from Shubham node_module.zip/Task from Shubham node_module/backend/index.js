const express = require("express");
const cors = require("cors");
const socketio = require("socket.io");
const mongoose = require("mongoose");
const expressAsyncErrors = require("express-async-errors");
const dataRouter = require("./routes/data");

/**express-async-errors is a third-party middleware for Express.js that simplifies the handling of asynchronous errors in Express routes and middleware functions. By default, Express doesn't handle asynchronous errors, and if an uncaught asynchronous error occurs in a route or middleware, it may crash the Node.js process. */

const app = express();
const server = require("http").createServer(app); // Create http server with express app as request handler
const io = new socketio.Server({
  allowEIO3: true, // false by default
  cors: {
    origin: true,
    credentials: true,
  },
}); // Socket.io server listens to http server

// const corsOptions = {
//   origin: "http://localhost:3000",
//   methods: ["GET", "POST"],
//   allowedHeaders: ["Content-Type"],
// };

app.use(cors());
app.use(express.json());
//expressAsyncErrors(app);
io.on("connection", (socket) => {
  console.log("A new client connected");

  // ... (handle real-time data updates and other WebSocket events)
  socket.on("disconnect", () => {
    console.log("A client disconnected");
  });
});

mongoose
  .connect("mongodb://127.0.0.1:27017/data_test")
  .then(() => {
    console.log("Connected to MongoDB");
  })
  .catch((err) => {
    console.log("Error connecting to MongoDB", err);
  });

app.use("/api", dataRouter);

app.post("/api/data", async (req, res) => {
  const { value } = req.body;

  if (!value || isNaN(value)) {
    return res.status(400).json({ message: "Invalid data value" });
  }

  try {
    const newData = new Data({ value });
    await newData.save();

    io.emit("dataUpdate", newData);

    res.status(201).json({ message: "Data saved successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

server.listen(8080, () => {
  console.log("Server running on port 8080");
});
