import React, { useEffect, useState } from "react";
import io from "socket.io-client";
import { Line } from "react-chartjs-2";
import {
  Chart,
  LinearScale,
  PointElement,
  LineController,
  LineElement,
} from "chart.js"; // Import the linear scale
import axios from "axios";

const socket = io.connect("http://localhost:8080");

export default function RealTimeChart() {
  const [data, setData] = useState([]);

  useEffect(() => {
    // Fetch initial data
    fetchData();

    // Set up socket.io to listen for real-time updates
    socket.on("dataUpdate", (newData) => {
      setData((prevData) => [...prevData, newData]);
    });
  }, []);

  const fetchData = async () => {
    try {
      const response = await axios.get("http://localhost:3000/api/data");
      const { data } = response;
      setData(data.map((item) => item.value));
    } catch (err) {
      console.error("Error fetching data:", err);
    }
  };

  const chartData = {
    labels: Array.from({ length: data.length }, (_, i) => (i + 1).toString()),
    datasets: [
      {
        label: "Live Data",
        data,
        fill: false,
        borderColor: "rgb(75, 192, 192)",
        tension: 0.1,
      },
    ],
  };

  const options = {
    scales: {
      x: {
        type: "linear",
        position: "bottom",
      },
    },
  };
  // Register the linear scale
  Chart.register(LinearScale, PointElement, LineController, LineElement);

  return <Line data={chartData} options={options} />;
}
