import "./App.css";
import { useState } from "react";
import axios from "axios";
import RealTimeChart from "./components/RealTimeChart";

function App() {
  const [value, setValue] = useState("");

  const handleAddData = async () => {
    try {
      const response = await axios.post("http://localhost:3000/api/data", {
        value,
      });
      console.log(response.data.message);
      setValue("");
    } catch (err) {
      console.error("Error adding data:", err);
    }
  };

  return (
    <div className="App">
      <h1>Live Data Charts</h1>
      <RealTimeChart />
      <div>
        <input
          type="number"
          value={value}
          onChange={(e) => setValue(e.target.value)}
        />
        <button onClick={handleAddData}>Add Data</button>
      </div>
    </div>
  );
}

export default App;
